import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';
import { Usuario } from '../models/usuario.model';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private api = 'http://localhost:3000';

  constructor(private http: HttpClient) {}

  login(nome: string, senha: string): Observable<Usuario> {
    return this.http.post<any>(`${this.api}/login`, { nome, senha }).pipe(
      map(res => ({
        id: res.id,
        nome: res.nome,
        senha: '',
        email: res.email
      }))
    );
  }

  salvarSessao(usuario: Usuario): void {
    sessionStorage.setItem('usuarioFord', JSON.stringify(usuario));
  }

  estaLogado(): boolean {
    return sessionStorage.getItem('usuarioFord') !== null;
  }

  sair(): void {
    sessionStorage.removeItem('usuarioFord');
  }
}
