# Desafio 7 - Angular / Ford Dashboard

Projeto montado com Angular, TypeScript, Bootstrap, RxJS e API REST local.

## 1. Abrir no VS Code
Abra a pasta `desafio7_ford_angular_FellipeFonseca` no VS Code.

## 2. Iniciar a API
Abra um terminal:

```bash
cd backend
npm install
npm start
```

A API deve ficar em `http://localhost:3000`.

## 3. Iniciar o Angular
Abra outro terminal:

```bash
cd frontend
npm install
npm start
```

Depois acesse `http://localhost:4200`.

## Login
- Usuário: `admin`
- Senha: `123456`

## VIN para teste
`2FRHDUYS2Y63NHD22454`

## O que foi usado
- Angular com módulos, componentes, rotas e serviços
- `ngModel`, `ngIf` e `ngFor`
- Bootstrap
- API REST (`/login`, `/vehicle`, `/vehicleData`)
- RxJS: `map`, `pluck`, `debounceTime`, `filter` e `distinctUntilChanged`
- Imagens originais do ZIP fornecido
